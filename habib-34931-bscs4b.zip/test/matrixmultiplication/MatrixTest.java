/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixmultiplication;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author DELL
 */
public class MatrixTest {
    
    public MatrixTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setMatrix method, of class Matrix.
     */
    @Test
    public void testSetMatrix() {
        System.out.println("setMatrix");
        Matrix instance = new Matrix();
        instance.setMatrix();
        // TODO review the generated test code and remove the default call to fail.
        
        fail("The test case is a prototype.");
    }

    /**
     * Test of IterativeMultiplication method, of class Matrix.
     */
    @Test
    public void testIterativeMultiplication() {
        System.out.println("IterativeMultiplication");
        Matrix M = null;
        Matrix instance = new Matrix();
        instance.IterativeMultiplication(M);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRows method, of class Matrix.
     */
    @Test
    public void testGetRows() {
        System.out.println("getRows");
        Matrix instance = new Matrix();
        int expResult = 0;
        int result = instance.getRows();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCols method, of class Matrix.
     */
    @Test
    public void testGetCols() {
        System.out.println("getCols");
        Matrix instance = new Matrix();
        int expResult = 0;
        int result = instance.getCols();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayMatrix method, of class Matrix.
     */
    @Test
    public void testDisplayMatrix() {
        System.out.println("displayMatrix");
        Matrix instance = new Matrix();
        instance.displayMatrix();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
