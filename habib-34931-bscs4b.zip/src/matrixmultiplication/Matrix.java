/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixmultiplication;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Matrix {
    
    private int rows;
    
    private int cols;
    
    /*private int[] data = new int[3];
    private List<int[]> rowlist=new ArrayList<int[]>();*/
    
    public int array[][];
    
    public Matrix(){rows=0;cols=0;}
    
    public Matrix(int rows,int cols){this.rows=rows;this.cols=cols;}
    
    public void setMatrix() //setting content of the matrix in this method
    { 
       
       Scanner input=new Scanner(System.in);
       int val=0;
       
       array=new int [rows][cols];
       
       for (int i=0;i<rows;i++)
       {
           for (int j=0;j<cols;j++)
           {
               System.out.println("M["+i+"]["+j+"]\n");
               array[i][j]=input.nextInt();
           }
       }
    }
    
    public void IterativeMultiplication(Matrix M) //Iterative algorithm implementation in this method
    {
        int resultarr[][]=new int [this.getRows()][M.getCols()];
        if (this.cols==M.rows)
        {
              for (int i = 0; i < this.getRows(); i++) {
           for (int j = 0; j < M.getCols(); j++) {
               for (int k = 0; k < this.getCols(); k++) {
                   resultarr[i][j] = resultarr[i][j] + this.array[i][k] * M.array[k][j];
               }
           }
       }
        }
        
        System.out.println("Resultant Multiplication matrix is:");
        for (int i=0;i<this.getRows();i++)
       {
           for (int j=0;j<M.getCols();j++)
           {
               System.out.println("RM["+i+"]["+j+":]"+resultarr[i][j]+"\n");
           }
       }
        
    }
    
    public int getRows() //getter function gives number of rows
    {
        return rows;
    }
    
    public int getCols() //getter function gives number of columns
    {
        return cols;
    }
    
    public void displayMatrix() //displays the Matrix content
    {
        for (int i=0;i<rows;i++)
       {
           for (int j=0;j<cols;j++)
           {
               System.out.println("M["+rows+"]["+cols+":]"+array[i][j]+"\n");
           }
       }
    }
    
    /*public static void add(Matrix M)
    {
        
    }*/
}
