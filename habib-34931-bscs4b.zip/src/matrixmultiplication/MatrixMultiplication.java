/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixmultiplication;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class MatrixMultiplication {

    /**
     * @param args the command line arguments
     */
    public static void main (String args[])
    {
        Scanner input=new Scanner(System.in);
        int r=0;
        int c=0;
        
        //Ask user for number of columns and rows for matrix 1
        System.out.println("Enter Matrix 1");
        System.out.println("Enter number of rows");
        r=input.nextInt();
        
        System.out.println("Enter number of Columns");
        c=input.nextInt();
        
        
        Matrix m1=new Matrix(r,c);
        
        //Ask user for number of columns and rows for matrix 2
        System.out.println("Enter Matrix 2 to multiply");
        System.out.println("Enter number of rows");
        r=input.nextInt();
        
        System.out.println("Enter number of Columns");
        c=input.nextInt();
        
        Matrix m2=new Matrix(r,c);
        
        //Set matrices
        m1.setMatrix();
        m2.setMatrix();
        
        //apply multiplication
        m1.IterativeMultiplication(m2);
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Strassen Multiplication Algorithm Test\n");
        /** Make an object of Strassen class **/
        strassen s = new strassen();
 
        System.out.println("Enter order n :");
        int N = scan.nextInt();
        /** Accept two 2d matrices **/
        System.out.println("Enter N order matrix 1\n");
        int[][] A = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                A[i][j] = scan.nextInt();
 
        System.out.println("Enter N order matrix 2\n");
        int[][] B = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                B[i][j] = scan.nextInt();
 
        int[][] C = s.multiply(A, B);
 
        System.out.println("\nProduct of matrices A and  B : ");
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
                System.out.print(C[i][j] +" ");
            System.out.println();
        }
    }
    
}
